class articles{
    articles_Nav(){
        cy.visit(data.MainWebsiteURL)
        cy.title().should('include',data.MainWebsiteTitle)
        cy.articlesNav().click()
        Cypress.config('defaultCommandTimeout', 30000);
    }
    LibraryNav(){
        cy.visit(data.MainWebsiteURL)
        cy.title().should('include',data.MainWebsiteTitle)
        cy.articlesNav().click()
        Cypress.config('defaultCommandTimeout', 30000);
    }
    Appling_To_CollegeNav(){
        cy.applyingToCollege().click();
        cy.url().should('include',data.ApplyWebsiteURL)
        cy.title().should('include',data.ApplyWebsiteTitle)
    }
    Test_PrepNav(){
        cy.testPrep().click();
        cy.url().should('include',data.TestPrepURL)
        cy.title().should('include',data.TestPrepTitle)
    }
    College_EssaysNav(){
        cy.collegeEssays().click();
        cy.url().should('include',data.CollegeEssaysURL)
        cy.title().should('include',data.CollegeEssaysTitle)
    }
    Paying_CollegeNav(){
        cy.payingForCollege().click();
        cy.url().should('include',data.PayingForCollegeURL)
        cy.title().should('include',data.PayingForCollegeTitle)
    }
}
export default articles