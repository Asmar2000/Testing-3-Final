class lists{
    articles_Nav(){
        cy.visit(data.MainWebsiteURL)
        cy.title().should('include',data.MainWebsiteTitle)
        cy.listsNav().click()
        Cypress.config('defaultCommandTimeout', 40000);
      }
      College_Ranking_NegtiveNav(){
        cy.collegeAndRanking().click()
        cy.url().should('include',data.CollegeAndRankingURL)
        cy.title().should('include',data.CollegeAndRankingTitle)
    }
    College_Ranking_PositiveNav(){
        cy.collegeAndRanking().click()
        cy.url().should('include',data.CollegeAndRankingURL)
        cy.title().should('be.empty')
    }
    Search_Result_Show(){
        cy.articlesPageTitle().should('be.visible') 
        cy.searchResutNumber().should('be.visible') 
    }
    College_CollectionNav(){
        cy.colleeCollections().click()
        cy.url().should('include',data.CollegeCollectionURL)
        cy.title().should('include',data.CollegeCollectionTitle)
    }
    MyFav_NoSignUp(){
        cy.myFavs().invoke('removeAttr', 'target').click()
        cy.url().should('include',data.MonsterCampaignURL)
    }
    MyFav_SIgnedIn(){
        cy.listsNav().click()
        cy.myFavs().click()
        cy.url().should('include',data.myFavURL)
    }
}
export default lists