Cypress.Commands.add('articlesNav', () => { 
   cy.get(':nth-child(4) > .list__item > .main-menu--item')
})
Cypress.Commands.add('category', () => { 
    cy.get("#id_category")
 })
 Cypress.Commands.add('authors', () => { 
    cy.get("#id_category")
 })
Cypress.Commands.add('articlesLibrarySearch', () => { 
    cy.get('#id_query')
 })
 Cypress.Commands.add('searchButton', () => { 
    cy.get('.hero-section__form__input__search > button')
 })
 Cypress.Commands.add('searchName', () => { 
    cy.get('.article-search-results-subtitle')
 })
 Cypress.Commands.add('searchResutNumber', () => { 
    cy.get('.article-search-results-counter')
 })
 Cypress.Commands.add('searchResultStack', () => { 
    cy.get('.cfojNP > :nth-child(1)')
 })
 Cypress.Commands.add('collegeAdviceStack', () => { 
    cy.get('.all-content-wrapper > :nth-child(6)')
})
 Cypress.Commands.add('readMoreButton', () => { 
    cy.get(':nth-child(6) > .l-row > :nth-child(1) > .l-flex-column-justify > .card__content__wrapper > .card__link__container > .card__link')
})
Cypress.Commands.add('standingOutStack', () => { 
    cy.get(':nth-child(1) > .cfojNP')
})
Cypress.Commands.add('articles', () => { 
    cy.get('[href="/articles/"]')
})
Cypress.Commands.add('applyingToCollege', () => { 
    cy.get('[href="/college-admissions-2023"]')
})
Cypress.Commands.add('schoolstoAddtoYourCollegeList', () => { 
    cy.get('.all-content-wrapper > :nth-child(7)')
})
Cypress.Commands.add('ifYouLikeAuburnButton', () => { 
    cy.get(':nth-child(7) > section > .forum-section > .forum-topics-list > :nth-child(1) > .card__link > svg > #CC-Overhaul-Kick-Off-February > #Assets > #ic_arrow_right')
})
Cypress.Commands.add('articleStack', () => { 
    cy.get('.section--colleges')
})
Cypress.Commands.add('exploreCollleges', () => { 
    cy.get('.logged-out-user > :nth-child(2)')
})
Cypress.Commands.add('exploreColllectionButton', () => { 
    cy.get(':nth-child(2) > .l-row > :nth-child(1) > .l-flex-column-justify > .card__content__wrapper > .card__link__container > .card__link')
})
Cypress.Commands.add('watchAreMyChancesStack', () => { 
    cy.get('.logged-out-user > :nth-child(3)')
})
Cypress.Commands.add('watchAreMyChancesButton', () => { 
    cy.get(':nth-child(3) > section > .forum-section > .forum-topics-list > :nth-child(1) > .card__link > svg')
})
Cypress.Commands.add('findMoreColleges', () => { 
    cy.get('.logged-out-user > :nth-child(4)')
})
Cypress.Commands.add('findMoreCollegesButton', () => { 
    cy.get(':nth-child(4) > section > .forum-section > .forum-topics-list > li > .card__link > [width="19px"]')
})
Cypress.Commands.add('latestButton', () => { 
    cy.get('#ember28 > .active')
})
Cypress.Commands.add('threadSearch', () => { 
    cy.get('#ember74-header')
})
Cypress.Commands.add('preCollegeIssues', () => { 
    cy.get('#ember155')
})
Cypress.Commands.add('programSearch', () => { 
    cy.get('#ember171-header')
})
Cypress.Commands.add('homeSchoolOption', () => { 
    cy.get('#ember218')
})
Cypress.Commands.add('tagsSearch', () => { 
    cy.get('#ember232-header')
})
Cypress.Commands.add('class2025', () => { 
    cy.get('#ember275')
})
Cypress.Commands.add('meetClass2027Stack', () => { 
    cy.get('.logged-out-user > :nth-child(7)')
})
Cypress.Commands.add('agnesScottConnect', () => { 
    cy.get(':nth-child(7) > .l-row > :nth-child(1) > .l-flex-column-justify > .card__content__wrapper > .card__link__container > .card__link')
})
Cypress.Commands.add('headerTitle', () => { 
    cy.get('h2 > :nth-child(1)')
})
Cypress.Commands.add('testPrep', () => { 
    cy.get('[href="/college-test-prep-sat-act"]')
})
Cypress.Commands.add('mainQuestions', () => { 
    cy.get('.page__container > :nth-child(4)')
})
Cypress.Commands.add('testPrepTopics', () => { 
    cy.get('.all-content-wrapper > :nth-child(6)')
})
Cypress.Commands.add('seeAllTopicsButton', () => { 
    cy.get('.card-collection--link > div')
})
Cypress.Commands.add('testPrepResources', () => { 
    cy.get('.all-content-wrapper > :nth-child(8)')
})
Cypress.Commands.add('testPrepForumDiscussions', () => { 
    cy.get('.all-content-wrapper > :nth-child(7)')
})
Cypress.Commands.add('articlesPageTitle', () => { 
    cy.get('.articles-page-title')
})
Cypress.Commands.add('filterTag', () => { 
    cy.get('[data-ccautocomplete-target="selectedContainer"]')
})
Cypress.Commands.add('collegeEssays', () => { 
    cy.get('[href="/college-essays-2023"]')
})
Cypress.Commands.add('collegeApplicationEssayWritingAdvice', () => { 
    cy.get('.all-content-wrapper > :nth-child(6)')
})
Cypress.Commands.add('tipsForWritingEssayPrompts', () => { 
    cy.get('.logged-out-user > :nth-child(2)')
})
Cypress.Commands.add('essaysByCollege', () => { 
    cy.get('.logged-out-user > :nth-child(3)')
})
Cypress.Commands.add('moreCollegeEssayExamples', () => { 
    cy.get('.logged-out-user > :nth-child(4)')
})
Cypress.Commands.add('searchTheForumsToDiscussCollegeApplicationEssays', () => { 
    cy.get('.logged-out-user > :nth-child(5)')
})
Cypress.Commands.add('faqsOnWritingCollegeApplicationEssays', () => { 
    cy.get(':nth-child(6) > section')
})
Cypress.Commands.add('payingForCollege', () => { 
    cy.get('[href="/paying-for-college"]')
})
Cypress.Commands.add('savingForCollege', () => { 
    cy.get('.all-content-wrapper > :nth-child(6)')
})
Cypress.Commands.add('fafsaFaq', () => { 
    cy.get('.logged-out-user > :nth-child(2)')
})
Cypress.Commands.add('studentLoanBasics', () => { 
    cy.get('.logged-out-user > :nth-child(3)')
})
Cypress.Commands.add('understandingAwardLetters', () => { 
    cy.get('.logged-out-user > :nth-child(5)')
})
Cypress.Commands.add('otherWaysToCoverCollegeCosts', () => { 
    cy.get('.logged-out-user > :nth-child(6)')
})
Cypress.Commands.add('budgetingForCollege', () => { 
    cy.get('.logged-out-user > :nth-child(7)')
})
Cypress.Commands.add('financialWellness', () => { 
    cy.get('.logged-out-user > :nth-child(8)')
})
Cypress.Commands.add('connectWithTheCommunity', () => { 
    cy.get('.logged-out-user > :nth-child(9)')
})
Cypress.Commands.add('ascentAd', () => { 
    cy.get(':nth-child(10) > .banner-cta-block-3 > div > a > .banner-desktop')
})
Cypress.Commands.add('authors', () => { 
    cy.get('#id_authors')
})
Cypress.Commands.add('clearAll', () => { 
    cy.get('.button--clear-all')
})
Cypress.Commands.add('collegeEssayTag', () => { 
    cy.get('.cta-section__tags-section__tags > :nth-child(1) > a')})
Cypress.Commands.add('selectedTags', () => { 
    cy.get('[data-filter-value="1"] > span')
})
Cypress.Commands.add('articlesTags', () => { 
    cy.get(':nth-child(1) > .article-card__main-section')
})

