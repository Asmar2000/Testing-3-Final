import articles from "../support/POM/articles-pom";
const article = new articles();
const { exists } = require("fs");
describe('Articles Section Tests', () => {
  beforeEach(function() {
    cy.fixture("article").then(function(data){
      globalThis.data=data;
    })
  });
  beforeEach(function() {
    article.articlesNav();
  });
  //1.Articles Library
  it('1.1- Articles Library Negative Search', () => {
    article.LibraryNav();
    cy.articlesLibrarySearch().type("arsany")
    cy.searchButton().click()
    cy.url().should('include','query=arsany')
  })
  it('1.2- Articles Library Postive Search', () => {
    article.LibraryNav();
    cy.articlesLibrarySearch().type("college")
    cy.searchButton().click()
    cy.url().should('include','query=college')
    cy.searchName().should('be.visible')
    cy.searchResutNumber().should('be.visible')
    cy.searchResultStack().should('be.visible')

  })
  it('1.3- Articles Library Filter', () => {
    article.LibraryNav();
    cy.category().select(data.PreparingForCollege)
    cy.articlesPageTitle().should('contain','Preparing for College')
    cy.authors().select(data.JoyBullen)
    cy.articlesTags().should('contain','Joy Bullen')
    cy.clearAll().click()
    cy.articlesPageTitle().should('contain','Explore Articles')
    cy.collegeEssayTag().click()
    cy.selectedTags().should('be.visible')
    cy.articlesTags().should('contain','College Essay')
  })
  //2.Applying To College
  it.only('2.1.1- Applying to college (College Admissions Advice)', () => {
    article.Appling_To_CollegeNav();
    cy.collegeAdviceStack().should('be.visible')
    cy.readMoreButton().click()
    cy.standingOutStack().should('be.visible')
    cy.url().should('include',data.StandOutInATestOptionalWorldURL)
    cy.title().should('include',data.StandOutInATestOptionalWorldTitle)
  })
  it('2.1.2- Applying to college (Schools to Add to Your College List)', () => {
    article.Appling_To_CollegeNav();
    cy.schoolstoAddtoYourCollegeList().should('be.visible')
    cy.ifYouLikeAuburnButton().click()
    cy.articleStack().should('be.visible')
    cy.url().should('include',data.AuburnURL)
    cy.title().should('include',data.AuburnTitle)
  })
  it('2.1.2- Applying to college (Explore Colleges)', () => {
    article.Appling_To_CollegeNav();
    cy.exploreCollleges().should('be.visible')
    cy.exploreColllectionButton().click()
    cy.url().should('include',data.BestSchoolsURL)
    cy.title().should('include',data.BestSchoolsTitle)
    cy.articleStack().should('be.visible')
  })
  it('2.1.3- Applying to college (What Are My Chances) ', () => {
    article.Appling_To_CollegeNav();
    cy.watchAreMyChancesStack().should('be.visible')
    cy.watchAreMyChancesButton().click()
    cy.url().should('include',data.ChanceMeURL)
    cy.title().should('include',data.ChanceMeTitle)
  })
  it('2.1.4- Applying to college (Find More Colleges) ', () => {
    article.Appling_To_CollegeNav();
    cy.findMoreColleges().should('be.visible')
    cy.findMoreCollegesButton().click()
    cy.url().should('include',data.FindCollegeUrl)
    cy.title().should('include',data.FindCollegeTitle)
    cy.latestButton().click()
    cy.url().should('include',data.FindCollegeLatestURL)
    cy.threadSearch().click()
    cy.preCollegeIssues().click()
    cy.url().should('include',data.FindCollegeLatestPreCollegeURL)
    cy.programSearch().click()
    cy.homeSchoolOption().click()
    cy.url().should('include',data.FindCollegeLatestPreCollegeHomeSchoolingURL)
    cy.tagsSearch().click()
    cy.class2025().click()
    cy.url().should('include',data.FindCollegeLatestPreCollegeHomeSchoolingClass2025URL)
  })
  it('2.1.5- Applying to college (Meet the Future Class of 2027) ', () => {
    article.Appling_To_CollegeNav();
    cy.meetClass2027Stack().should('be.visible')
    cy.agnesScottConnect().click()
    cy.title().should('include',data.AgnesScottCollegeTitle)
    cy.url().should('include',data.AgnesScottCollegeURL)
    cy.headerTitle().should('contain',data.AgnesScottCollegeTitle)
  })
  //3.Test Prep
  it('3.1-Testing Page Content ', () => {
    article.Test_PrepNav();
    cy.mainQuestions().should('be.visible')
    cy.testPrepTopics().should('be.visible')
    cy.testPrepResources().should('be.visible')
    cy.testPrepForumDiscussions().should('be.visible')
    cy.seeAllTopicsButton().click()
    cy.url().should('include','articles')
    cy.articlesPageTitle().should('contain','Explore Articles')
    cy.filterTag().should('be.visible')
  })
  //4.College Essays
  it ('4.1- Testing Page Content ', () => {
    article.College_EssaysNav();
    cy.collegeApplicationEssayWritingAdvice().should('be.visible')
    cy.tipsForWritingEssayPrompts().should('be.visible')
    cy.essaysByCollege().should('be.visible')
    cy.moreCollegeEssayExamples().should('be.visible')
    cy.searchTheForumsToDiscussCollegeApplicationEssays().should('be.visible')
    cy.faqsOnWritingCollegeApplicationEssays().should('be.visible')
  })
  //5. Paying For College
  it ('5.1- Paying for College Content ', () => {
    article.Paying_CollegeNav();
    cy.savingForCollege().should('be.visible')
    cy.fafsaFaq().should('be.visible')
    cy.studentLoanBasics().should('be.visible')
    cy.understandingAwardLetters().should('be.visible')
    cy.otherWaysToCoverCollegeCosts().should('be.visible')
    cy.budgetingForCollege().should('be.visible')
    cy.financialWellness().should('be.visible')
    cy.connectWithTheCommunity().should('be.visible')
    cy.ascentAd().should('be.visible')
})
})
