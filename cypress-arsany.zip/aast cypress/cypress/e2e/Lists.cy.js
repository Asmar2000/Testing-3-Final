import lists from "../support/POM/lists-pom";
const { exists } = require("fs");
const list = new lists();
Cypress.on('uncaught:exception', (err, runnable) => {
  // returning false here prevents Cypress from
  // failing the test in te login form 
  return false
})
describe('Articles Section Tests', () => {
  beforeEach(function() {
    cy.fixture("list").then(function(data){
      globalThis.data=data;
    })
  });
  beforeEach(function() {
      list.articles_Nav();
  });
  //1.College And Ranking
  it('1.1- College And Ranking Filter (Negative Title)', () => {  //There IS No Title for the page
   list.College_Ranking_NegtiveNav();
   })
  it('1.2- College And Ranking Filter (Postive Title) - College Confidential Filter', () => {
    list.College_Ranking_PositiveNav();
    cy.collegeConfidentialCheckBox().click()
    cy.searchResult().should('be.visible')
    cy.createdAuthor().should('contain','College Confidential') 
    list.Search_Result_Show(); 
   })
   it('1.3- College And Ranking Filter (Postive Title) - Community Filter', () => {
    list.College_Ranking_PositiveNav();
    cy.commuunityCheckBox().click()
    cy.searchResult().should('be.visible')
    cy.createdAuthor().should('not.be.visible') 
    list.Search_Result_Show(); 
   })
   it('1.4- College And Ranking Filter (Postive Title) - Featured', () => {
    list.College_Ranking_PositiveNav();
    cy.featuredCheckBox().click()
    cy.searchResult().should('contain','RANKED')
    cy.searchResult().should('be.visible')
    cy.articlesPageTitle().should('be.visible') 
    cy.searchResutNumber().should('be.visible')
 
   })
   it('1.5- College And Ranking Filter (Postive Title) - Ranked', () => {
    list.College_Ranking_PositiveNav();
    cy.rankedCheckBox().click()
    cy.rankedTag().should('be.visible')
    cy.searchResult().should('contain','RANKED')
    cy.searchResult().should('be.visible')
    list.Search_Result_Show();
   })
   it('1.6- College And Ranking Filter (Postive Title) - Unranked', () => {
    list.College_Ranking_PositiveNav();
    cy.unrankedCheckBox().click()
    cy.searchResult().should('not.contain','RANKED')
    cy.searchResult().should('be.visible')
    list.Search_Result_Show();
   })
   it('1.7- College And Ranking Filter (Postive Title) - Collee Name Search', () => {
    list.College_Ranking_PositiveNav();
    cy.collegeNameSearch().type("Agnes Scott")
    cy.searchOption().click() //Agnes Scott Option
    cy.collegeNameSearchTag().should('be.visible')
    cy.collegeNameSearchTag().should('contain','Agnes Scott')
    cy.searchResult().should('be.visible')
    list.Search_Result_Show();
   })
   it('1.8- College And Ranking Filter (Postive Title) - Location Search', () => {
    list.College_Ranking_PositiveNav();
    cy.locationSearch().type("Alabama")
    cy.searchOption().click() //Alabama Option
    cy.searchResult().should('be.visible')
    cy.articlesPageTitle().should('be.visible') 
    cy.searchResutNumber().should('be.visible')
    cy.locationSearchTag().should('contain','Alabama')
   })
   //2.College Collections
   it('2.1. Check Page Content', () => {
    list.College_CollectionNav();
    cy.headerImage().should('be.visible')
    cy.collegeSteps().should('be.visible')
    cy.contentImage().should('be.visible')
    cy.knowledeContent().should('be.visible')
    cy.sampleCOntent().should('be.visible')
    cy.createButton().click()
    cy.url().should('include',data.CollegeAndRankingURL)
    cy.visit(data.CollegeCollectionURL)
    cy.browseButton().click()
    cy.url().should('include',data.CollegeAndRankingURL)
   })
   //3.My Favorites
   it('3.1 Check if not signed up (sign up)', () => {
    list.MyFav_NoSignUp();
    cy.signup_OR_login_AD().should('be.visible')
    cy.signupButton().click()
    cy.signUpForm().should('be.visible')
   })
   it('3.2 Check if not signed up (sign in)', () => {
    list.MyFav_NoSignUp();
    cy.signup_OR_login_AD().should('be.visible')
    cy.signinButton().click()
    cy.loginForm().should('be.visible') 
   })
   it('3.3 Check if signed up / signed in', () => {
    cy.loginButton().click()
    cy.loginForm().should('be.visible') 
    cy.loginUserTextBox().type(data.UserName) 
    cy.loginPasswordTextBox().type(data.Password) 
    cy.loginFormButton().click()
    list.MyFav_SIgnedIn();
    cy.searchCollegeButton().click()
    cy.addToFavoriteButton().click()
    cy.addedToFavoritesAlert().should('be.visible')
    list.MyFav_SIgnedIn();
    cy.favSection().should('contain','University') 
   })
})