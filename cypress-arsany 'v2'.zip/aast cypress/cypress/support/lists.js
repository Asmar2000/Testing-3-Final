Cypress.Commands.add('listsNav', () => { 
    cy.get(':nth-child(3) > .list__item > .main-menu--item')
 })
 Cypress.Commands.add('collegeAndRanking', () => { 
    cy.get('[href="/lists/"]')
})
Cypress.Commands.add('collegeConfidentialCheckBox', () => { 
    cy.get('#id_added_by_0')
})
Cypress.Commands.add('createdAuthor', () => { 
    cy.get(':nth-child(1) > .college-card > .card--content > .card--content_header > .editor > span')
    
})
Cypress.Commands.add('commuunityCheckBox', () => { 
    cy.get('#id_added_by_1')
})
Cypress.Commands.add('searchResult', () => { 
    cy.get('.section--colleges')
})
Cypress.Commands.add('featuredCheckBox', () => { 
    cy.get('#id_ranked_0')
})
Cypress.Commands.add('rankedTag', () => { 
    cy.get('[href="/lists/forbes-top-25-colleges-of-2021/"] > .editor_list_collage_wrapper > .collage_img_main > .card-tag')
})
Cypress.Commands.add('rankedCheckBox', () => { 
    cy.get('#id_ranked_1')
})
Cypress.Commands.add('unrankedCheckBox', () => { 
    cy.get('#id_ranked_2')
})
Cypress.Commands.add('collegeNameSearch', () => { 
    cy.get(':nth-child(6) > .autocomplete > [type="text"]')
})
Cypress.Commands.add('locationSearch', () => { 
    cy.get(':nth-child(9) > .autocomplete > [type="text"]')
})
Cypress.Commands.add('searchOption', () => { 
    cy.get('#-option-0')
})
Cypress.Commands.add('collegeNameSearchTag', () => { 
    cy.get('[data-filter-value="25"]')
})
Cypress.Commands.add('locationSearchTag', () => { 
    cy.get('[data-filter-value="AL"]')
})
Cypress.Commands.add('colleeCollections', () => { 
    cy.get('[href="/college-collections"]')
})
Cypress.Commands.add('headerImage', () => { 
    cy.get('.banner-cta-block-2')
})
Cypress.Commands.add('collegeSteps', () => { 
    cy.get('.banner-cta-block-2')
})
Cypress.Commands.add('contentImage', () => { 
    cy.get('.banner-cta-block-2')
})
Cypress.Commands.add('knowledeContent', () => { 
    cy.get(':nth-child(6) > .faq--section')
})
Cypress.Commands.add('sampleCOntent', () => { 
    cy.get('.all-content-wrapper > :nth-child(6)')
})
Cypress.Commands.add('createButton', () => { 
    cy.get('.header-content__container > .button--cta')
})
Cypress.Commands.add('browseButton', () => { 
    cy.get('.split--section_text-content > .button--cta')
})
Cypress.Commands.add('myFavs', () => { 
    cy.get('.dropdown-menu > .nav__item--icon')
})
Cypress.Commands.add('signup_OR_login_AD', () => { 
    cy.get('.losthills-row-inner')
})
Cypress.Commands.add('signupButton', () => { 
    cy.get('#losthills-YesButtonElement--dE5MYmeZ5UkNBDbEYS5N')
})
Cypress.Commands.add('signUpForm', () => { 
    cy.get('.create-account-form')
})
Cypress.Commands.add('signinButton', () => { 
    cy.get('#losthills-NoButtonElement--dE5MYmeZ5UkNBDbEYS5N')
})
Cypress.Commands.add('loginForm', () => { 
    cy.get('#ember69')
})
Cypress.Commands.add('loginButton', () => { 
    cy.get('.nav__auth > .u-margin-left-lg')
})
Cypress.Commands.add('loginUserTextBox', () => { 
    cy.get('#login-account-name')
})
Cypress.Commands.add('loginPasswordTextBox', () => { 
    cy.get('#login-account-password')
})
Cypress.Commands.add('loginFormButton', () => { 
    cy.get('#login-button')
})
Cypress.Commands.add('searchCollegeButton', () => { 
    cy.get('.search--for--colleges > .button--cta')
})
Cypress.Commands.add('addToFavoriteButton', () => { 
    cy.get(':nth-child(1) > .college-card > .card__link__wrapper > :nth-child(2) > .list-card-root > .js-school-favorite > .far')
})
Cypress.Commands.add('addedToFavoritesAlert', () => { 
    cy.get('#alert--favorites')
})
Cypress.Commands.add('favSection', () => { 
    cy.get('.section--colleges')
})