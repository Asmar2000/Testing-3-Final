import articles from "../support/POM/articles-pom";
const article = new articles();
const { exists } = require("fs");
describe('Articles Section Tests', () => {
  beforeEach(function() {
    cy.fixture("article").then(function(data){
      globalThis.data=data;
    })
  });
  beforeEach(function() {
    article.articlesNav();
  });
  //1.Articles Library
  it('1.1- Articles Library Negative Search', () => {
    article.LibraryNav()
    article.article_library_negative_search()
  })
  it('1.2- Articles Library Postive Search', () => {
    article.LibraryNav()
    article.article_library_positive_search()

  })
  it('1.3- Articles Library Filter', () => {
    article.LibraryNav()
    article.chech_PreparingForCollege_JoyBullen_Filter()
    article.check_ClearAll_Button()
  })
  //2.Applying To College
  it.only('2.1.1- Applying to college (College Admissions Advice)', () => {
    article.Appling_To_CollegeNav();
    article.college_admission_advices_function()
  })
  it.only('2.1.2- Applying to college (Schools to Add to Your College List)', () => {
    article.Appling_To_CollegeNav();
    article.schools_to_add_function()
  })
  it.only('2.1.3- Applying to college (Explore Colleges)', () => {
    article.Appling_To_CollegeNav()
    article.explore_more_colleges_function()
  })
  it.only('2.1.4- Applying to college (What Are My Chances) ', () => {
    article.Appling_To_CollegeNav()
    article.what_are_my_chances_function()
  })
  it('2.1.5- Applying to college (Find More Colleges) ', () => {
    article.Appling_To_CollegeNav()
    article.find_more_colleges_function()
    article.check_FindMoreCollege_URL()
    article.latest_button_function()
    article.search_by_thread_function()
    article.search_by_school_type()
    article.search_by_tag_function()
  })
  it('2.1.6- Applying to college (Meet the Future Class of 2027) ', () => {
    article.Appling_To_CollegeNav()
    article.check_meet_class_function()
  })
  //3.Test Prep
  it('3.1-Testing Page Content ', () => {
    article.Test_PrepNav()
    article.test_prep_content()
    article.test_prep_see_all_button()
  })
  //4.College Essays
  it ('4.1- Testing Page Content ', () => {
    article.College_EssaysNav()
    article.check_college_essays_content()
  })
  //5. Paying For College
  it ('5.1- Paying for College Content ', () => {
    article.Paying_CollegeNav()
    article.check_paying_for_college_content()
})
})
