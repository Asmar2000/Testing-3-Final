import lists from "../support/POM/lists-pom";
const { exists } = require("fs");
const list = new lists();
Cypress.on('uncaught:exception', (err, runnable) => {
  // returning false here prevents Cypress from
  // failing the error in the login form 
  return false
})
describe('Articles Section Tests', () => {
  beforeEach(function() {
    cy.fixture("list").then(function(data){
      globalThis.data=data;
    })
  });
  beforeEach(function() {
      list.articles_Nav();
  });
  //1.College And Ranking
  it('1.1- College And Ranking Filter (Negative Title)', () => {  //There IS No Title for the page
   list.College_Ranking_NegtiveNav();
   })
  it('1.2- College And Ranking Filter (Postive Title) - College Confidential Filter', () => {
    list.College_Ranking_PositiveNav()
    list.college_confi_filter();
    list.Search_Result_Show();
   })
   it('1.3- College And Ranking Filter (Postive Title) - Community Filter', () => {
    list.College_Ranking_PositiveNav()
    list.community_filter()
    list.Search_Result_Show() 
   })
   it('1.4- College And Ranking Filter (Postive Title) - Featured', () => {
    list.College_Ranking_PositiveNav()
    list.featred_filter()
 
   })
   it('1.5- College And Ranking Filter (Postive Title) - Ranked', () => {
    list.College_Ranking_PositiveNav()
    list.ranked_filter()
    list.Search_Result_Show()
   })
   it('1.6- College And Ranking Filter (Postive Title) - Unranked', () => {
    list.College_Ranking_PositiveNav()
    list.unraked_filter()
    list.Search_Result_Show()
   })
   it('1.7- College And Ranking Filter (Postive Title) - Collee Name Search', () => {
    list.College_Ranking_PositiveNav()
    list.college_search()
    list.Search_Result_Show();
   })
   it('1.8- College And Ranking Filter (Postive Title) - Location Search', () => {
    list.College_Ranking_PositiveNav()
    list.location_search()
   })
   //2.College Collections
   it.only('2.1. Check College Collections Content', () => {
    list.College_CollectionNav()
    list.college_collection_content()
    list.college_collection_buttons()
   })
   //3.My Favorites
   it('3.1 Check if not signed up (sign up)', () => {
    list.MyFav_NoSignUp()
    list.check_signup_form()
   })
   it('3.2 Check if not signed up (sign in)', () => {
    list.MyFav_NoSignUp();
    list.check_signin_form()
   })
   it('3.3 Check if signed up / signed in', () => {
    list.login_user()
    list.MyFav_SIgnedIn();
    list.add_to_fav()
    list.check_fav_alert()
    list.MyFav_SIgnedIn();
    list.check_added_to_fav() 
   })
})